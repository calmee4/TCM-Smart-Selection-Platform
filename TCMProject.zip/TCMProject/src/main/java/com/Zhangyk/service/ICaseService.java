package com.Zhangyk.service;

import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.CaseDTO;
import com.Zhangyk.bean.PageRequestDTO;

public interface ICaseService {
    
    PageInfo<CaseDTO> getCaseList(PageRequestDTO<CaseDTO> page);

    PageInfo<CaseDTO> getCaseListByPatientName(String patientName, int pageNum, int pageSize);

    int creatCase(CaseDTO caseInfo);
    
    int updateCase(CaseDTO caseInfo);
    
    CaseDTO getCase(Integer caseId);


}

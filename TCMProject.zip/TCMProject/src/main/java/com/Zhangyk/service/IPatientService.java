package com.Zhangyk.service;

import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.PageRequestDTO;
import com.Zhangyk.bean.PatientDTO;

public interface IPatientService {
    
    int creatPatient(PatientDTO patient);
    
    PatientDTO updatePatient(PatientDTO patient);
    
    PageInfo<PatientDTO> PatientList(PageRequestDTO<PatientDTO> pagepatient);
    
    int delete (Integer patientId);

    PatientDTO getPatientById(Integer patientId);

}

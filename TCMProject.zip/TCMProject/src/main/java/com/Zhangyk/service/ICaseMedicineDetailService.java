package com.Zhangyk.service;

import java.util.List;

import com.Zhangyk.bean.CaseMedicineDetailDTO;

public interface ICaseMedicineDetailService {
    
    int creatCaseDeatil(int caseId,List<CaseMedicineDetailDTO> detailList);
    
    List<CaseMedicineDetailDTO> getListByCaseId(Integer caseId);

}

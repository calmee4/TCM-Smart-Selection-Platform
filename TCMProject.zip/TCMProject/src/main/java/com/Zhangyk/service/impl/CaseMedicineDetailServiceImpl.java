package com.Zhangyk.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Zhangyk.bean.CaseMedicineDetailDTO;
import com.Zhangyk.mapper.ICaseMedicineDetailMapper;
import com.Zhangyk.service.ICaseMedicineDetailService;

@Service
public class CaseMedicineDetailServiceImpl implements ICaseMedicineDetailService {

    @Autowired
    ICaseMedicineDetailMapper caseMedicineDetailMapper;
    
    @Override
    public int creatCaseDeatil(int caseId,List<CaseMedicineDetailDTO> detailList) {
        int detailNum = 0;
        if(detailList != null) {
            for (CaseMedicineDetailDTO datail : detailList) {
                datail.setCaseId(caseId);
                detailNum += caseMedicineDetailMapper.insertSelective(datail);
            }
        }
        return detailNum;
    }
    
    @Override
    public List<CaseMedicineDetailDTO> getListByCaseId(Integer caseId){
        return caseMedicineDetailMapper.queryDetailList(caseId);
    }
    
    

}

package com.Zhangyk.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.CaseDTO;
import com.Zhangyk.bean.CaseMedicineDetailDTO;
import com.Zhangyk.bean.PageRequestDTO;
import com.Zhangyk.mapper.ICaseMapper;
import com.Zhangyk.mapper.ICaseMedicineDetailMapper;
import com.Zhangyk.service.ICaseService;

@Service
public class CaseServiceServiceImpl implements ICaseService{

    @Autowired
    ICaseMapper caseMapper;
    
    @Autowired
    ICaseMedicineDetailMapper caseMedicineDetailMapper;
    
    @Override
    public PageInfo<CaseDTO> getCaseList(PageRequestDTO<CaseDTO> page) {
        PageHelper.startPage(page.getPageNum(), page.getPageSize());
        List<CaseDTO> list = caseMapper.queryCaseList(page.getParam());
        for (CaseDTO ca : list) {
            List<CaseMedicineDetailDTO> detailList = caseMedicineDetailMapper.queryDetailList(ca.getCaseId());
            if(detailList.size()>0)
                ca.setCaseDetail(detailList);
        }
        return new PageInfo<CaseDTO>(list);
    }

    @Override
    public PageInfo<CaseDTO> getCaseListByPatientName(String patientName, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        CaseDTO caseDTO = new CaseDTO();
        caseDTO.setPatientName(patientName);
        List<CaseDTO> list = caseMapper.queryCaseList(caseDTO);
        for (CaseDTO dto : list) {
            // 可以在这里添加获取药品详情的逻辑
        }
        return new PageInfo<>(list);
    }

    @Override
    public int creatCase(CaseDTO caseInfo) {
        return caseMapper.insertSelective(caseInfo);        
    }

    @Override
    public int updateCase(CaseDTO caseInfo) {
        return caseMapper.updateByPrimaryKeySelective(caseInfo);
    }

    @Override
    public CaseDTO getCase(Integer caseId) {
        CaseDTO caseInfo = caseMapper.selectByPrimaryKey(caseId);
        if(caseInfo != null) {
            List<CaseMedicineDetailDTO> detailList = caseMedicineDetailMapper.queryDetailList(caseId);
            if(detailList != null)
                caseInfo.setCaseDetail(detailList);
        }
        return caseInfo;
    }

}

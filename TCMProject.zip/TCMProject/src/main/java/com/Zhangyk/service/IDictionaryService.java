package com.Zhangyk.service;

import java.util.Map;

public interface IDictionaryService {
    
    Map<Integer, String> getCodeName(String type);
    
    Map<String, String> getNameCode(String type);

}

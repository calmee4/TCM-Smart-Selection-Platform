package com.Zhangyk.service;

import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.DoctorDTO;
import com.Zhangyk.bean.PageRequestDTO;

public interface IDoctorService {
    
    int creatDoctor(DoctorDTO doctor);
    
    DoctorDTO updateDoctor(DoctorDTO doctor);
    
    PageInfo<DoctorDTO> DoctorList(PageRequestDTO<DoctorDTO> pageDoctor);
    
    int delete (Integer doctorId);

}

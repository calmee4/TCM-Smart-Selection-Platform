package com.Zhangyk.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.DoctorDTO;
import com.Zhangyk.bean.PageRequestDTO;
import com.Zhangyk.bean.PatientDTO;
import com.Zhangyk.bean.UseraccountDTO;
import com.Zhangyk.enums.UserTypeEnum;
import com.Zhangyk.mapper.IDoctorMapper;
import com.Zhangyk.mapper.IPatientMapper;
import com.Zhangyk.mapper.IUseraccountMapper;
import com.Zhangyk.service.IUseraccountService;

@Service
public class UseraccountServiceImpl implements IUseraccountService {

    @Autowired
    IUseraccountMapper useraccountMapper;
    
    @Autowired
    IDoctorMapper doctorMapper;
    
    @Autowired
    IPatientMapper patientMapper;

    @Override
    public UseraccountDTO verificationLoginUser(UseraccountDTO loginUser) throws Exception {
        String loginName = loginUser.getUserName();
        UseraccountDTO exiseUser = useraccountMapper.selectByAccount(loginName);
        if(exiseUser == null || !(exiseUser.getPassword().equals(loginUser.getPassword())) ) {
            return null;
        }else {
            int type = Integer.parseInt(exiseUser.getUserType());
            if(type == UserTypeEnum.USER_TYPE_DOCTOR.getTypeCode()){
                DoctorDTO doctor = doctorMapper.selectByUserId(exiseUser.getUserId());
                if(null != doctor)
                  exiseUser.setDoctor(doctor);
            }else if(type == UserTypeEnum.USER_TYPR_PATIENT.getTypeCode()) {
                PatientDTO patient=patientMapper.selectByUserId(exiseUser.getUserId());
                exiseUser.setPatient(patient);
                // 新增：强制绑定患者姓名（核心修复）
                String pName = patient != null && patient.getPatientName() != null
                        ? patient.getPatientName().trim() // 数据库已有姓名
                        : "患者" + exiseUser.getUserId(); // 无姓名时生成默认值（如：患者123）
                exiseUser.setUserName(pName);
            }
            return exiseUser;
        }  
    }

    /**
     * 创建user 0->name错误  -1 -> 未知错误  >0 添加成功
     */
    @Override
    public int creadUseraccount(UseraccountDTO user) {
        
        String phoneRegex = "[0-9]{11}";
        if(!user.getUserPhone().matches(phoneRegex))
            return 0;
        else if(useraccountMapper.insertSelective(user)>0)
            return 1;
        else
            return -1;
    }

    /**
     * 分页查询出 按要求 查出的list
     */
    @Override
    public PageInfo<UseraccountDTO> queryUserList(PageRequestDTO<UseraccountDTO> pageUser) {
        
        PageHelper.startPage(pageUser.getPageNum(),pageUser.getPageSize());
        
        List<UseraccountDTO> list = useraccountMapper.queryUserList(pageUser.getParam());
        
        return new PageInfo<UseraccountDTO>(list);
    }

    
    /**
     * 更改信息 返回 更改后的信息
     */
    @Override
    public UseraccountDTO updateUser(UseraccountDTO user) {
        int isUpdate = useraccountMapper.updateByPrimaryKeySelective(user);
        if(isUpdate < 0) 
            return null;
        else
            return useraccountMapper.selectByPrimaryKey(user.getUserId());
    }
    
    @Override
    public UseraccountDTO getUserFull(Integer userId) {
        UseraccountDTO user = useraccountMapper.selectByPrimaryKey(userId);
        if("2".equals(user.getUserType())) {
            user.setDoctor(doctorMapper.selectByUserId(userId));
            return user;
        }else if("3".equals(user.getUserType())) {
            user.setPatient(patientMapper.selectByUserId(userId));
            return user;
        }else {
            return null;
        }
    }

    @Override
    public DoctorDTO queryDoctorById(Integer id) {
        
        return doctorMapper.selectByPrimaryKey(id);
    }

    @Override
    public PatientDTO queryPatientById(Integer id) {
        
        return patientMapper.selectByUserId(id);
    }

    @Override
    public int verfiy(UseraccountDTO user) {
        if(null != useraccountMapper.selectByNamePhone(user))
            return 1;
        else
            return 0;
    }

    @Override
    public List<PatientDTO> queryPatientName(PatientDTO patient) {
        
        return patientMapper.queryPatientList(patient);
    }

}

package com.Zhangyk.service;

import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.InformationDTO;
import com.Zhangyk.bean.PageRequestDTO;

public interface IInformationService {
    
    /**
     * 增
     */
    int creatInformation(InformationDTO information);
    /**
     * 删
     */
    int delInformation(Integer infoId);
    /**
     * 改
     */
    InformationDTO updateInformation(InformationDTO information);
    /**
     * 查(分页查询->info message)
     */
    PageInfo<InformationDTO> getInfoList(PageRequestDTO<InformationDTO> pageInformation);
    /**
     * 查(根据 infoId 查 该条信息详情)
     */
    InformationDTO getInformation(Integer infoId);
    
}

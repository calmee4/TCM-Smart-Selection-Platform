package com.Zhangyk.controller;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.github.pagehelper.PageInfo;
import com.Zhangyk.bean.CaseDTO;
import com.Zhangyk.bean.CaseInfoDTO;
import com.Zhangyk.bean.CaseMedicineDetailDTO;
import com.Zhangyk.bean.PageRequestDTO;
import com.Zhangyk.bean.PatientDTO;
import com.Zhangyk.bean.UseraccountDTO;
import com.Zhangyk.service.ICaseMedicineDetailService;
import com.Zhangyk.service.ICaseService;
import com.Zhangyk.service.IPatientService;
import com.Zhangyk.service.IUseraccountService;
import com.Zhangyk.util.ResultDTO;

@RestController
@RequestMapping
public class CaseController {
    
    @Autowired
    ICaseService caseService;
    
    @Autowired
    IPatientService patientService;
    
    @Autowired
    IUseraccountService  useraccountService;
     
    @Autowired
    ICaseMedicineDetailService caseMedicineDetailService;
    
    //case/saveCase 填写处方单
    @RequestMapping(value = "/case/saveCase",method=RequestMethod.POST)
    public ResultDTO<Integer> saveCase(@RequestBody CaseInfoDTO caseInfo,HttpSession session){
        
        BigDecimal medicinePrice = new BigDecimal(0);
        for (CaseMedicineDetailDTO detail : caseInfo.getDetailList()) {
            medicinePrice = medicinePrice.add(detail.getTotalPrice());
        }
        
        UseraccountDTO loginUser =(UseraccountDTO) session.getAttribute("logUser");
        
        //判断此人是否在数据库中（根据是否有patientID传值 如何存在就是数据库的老病人，如果没有就是新病人）
        //useraccountService.queryPatientName(patient).size() < 1
        PatientDTO patient = null;
        if(null == caseInfo.getPatientId() || caseInfo.getPatientId().equals("")) {
            patient = new PatientDTO();
            patient.setPatientName(caseInfo.getPatientName());
            patient.setPatientSex(caseInfo.getPatientSex().equals("男") ? "M":"F");
            patient.setPatientBorn(caseInfo.getPatientAge());
            patientService.creatPatient(patient);
        }
        CaseDTO caseInset = new CaseDTO();
        caseInset.setIllnessDesc(caseInfo.getIllnessDesc());
        if(null != patient) {
            caseInset.setPatientName( patient.getPatientId()+"-"+caseInfo.getPatientName());
        }else {
            caseInset.setPatientName( caseInfo.getPatientId()+"-"+caseInfo.getPatientName());
        }
        caseInset.setDoctorName(caseInfo.getDoctorName());
        caseInset.setIllnessTime(caseInfo.getIllnessTime());
        caseInset.setCureCycle(caseInfo.getCureCycle());
        caseInset.setCureTime(caseInfo.getCureTime());
        caseInset.setMedicineTotalPrice(medicinePrice);
        caseInset.setIllnessGrade(caseInfo.getIllnessGrade());
        //加入session 中的登陆用户的
        caseInset.setEnterPerson(String.valueOf(loginUser.getDoctor().getDoctorId()));
        caseService.creatCase(caseInset);
        int caseId = caseInset.getCaseId();
        
        int detail = caseMedicineDetailService.creatCaseDeatil(caseId,caseInfo.getDetailList());
        if(caseId > 0 && detail >0 ) 
            return ResultDTO.valueOfSuccess();
        else
            return ResultDTO.valueOfError("新建处方单时出现错误");
    }
    
    //查询处方单 得到登陆用户的所创建的 处方单
    @RequestMapping(value="/case/getCaseList",method=RequestMethod.POST)
    public ResultDTO<PageInfo<CaseDTO>> getCaseByDoctor(@RequestBody PageRequestDTO<CaseDTO> caseinfo, HttpSession session){
        //得到登陆用户
        /*UseraccountDTO loginUser = (UseraccountDTO) session.getAttribute("logUser");
        String doctorName = String.valueOf(loginUser.getDoctor().getDoctorName());
        caseinfo.getParam().setEnterPerson(doctorName);*/
        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
    }

    // 查询患者的处方单
    @RequestMapping(value = "/getCaseListByPatient", method = RequestMethod.POST)
    public ResultDTO<PageInfo<CaseDTO>> getCaseByPatient(@RequestBody PageRequestDTO<CaseDTO> caseinfo, HttpSession session) {
        // 从会话中获取登录用户
        UseraccountDTO loginUser = (UseraccountDTO) session.getAttribute("logUser");
        Integer patientId = loginUser.getPatient().getPatientId();
        //caseinfo.getParam().setPatientId(patientId);

        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
    }

    public void printChar(HttpServletResponse response,HttpServletRequest request ) {
        //response
//        request.get
        
        
    }
    ///case/getCaseName
    @RequestMapping(value="/case/getCaseName",method=RequestMethod.POST)
    public ResultDTO<PageInfo<CaseDTO>> getCaseListByIllName(@RequestBody PageRequestDTO<CaseDTO> caseinfo){
        
        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
        
    }
    
    
    //根据 casdid 查出改信息的所有内容
    @RequestMapping(value="/case/getCaseAll/{caseId}",method=RequestMethod.GET)
    public ResultDTO<CaseInfoDTO> getCaseAll(@PathVariable("caseId") Integer caseId){
        //case 
        CaseDTO caseInfo = caseService.getCase(caseId);
        //medicine
        List<CaseMedicineDetailDTO> detailList = caseMedicineDetailService.getListByCaseId(caseId);
        String patientName = caseInfo.getPatientName();
        String[] idName = patientName.split("-");
        //patient
        PatientDTO patient = patientService.getPatientById(Integer.parseInt(idName[0]));
        
        return ResultDTO.valueOfSuccess(fillCaseAll(caseInfo, patient, detailList));
        
    }

    // 查询所有已存病例
    // 在 CaseController 中添加（或复用 getAllCaseList）
    @RequestMapping(value="/case/getAllCaseList", method=RequestMethod.POST)
    public ResultDTO<PageInfo<CaseDTO>> getAllCaseList(@RequestBody PageRequestDTO<CaseDTO> caseinfo) {
        // 移除 enterPerson 过滤，直接查询所有病例
        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
    }

    // 查询患者自己的病例
    @RequestMapping(value="/case/getCaseListByPatient", method=RequestMethod.POST)
    public ResultDTO<PageInfo<CaseDTO>> getCaseListByPatient(@RequestBody PageRequestDTO<CaseDTO> caseinfo, HttpSession session) {
        // 从 session 中获取患者 ID，这里假设 session 中存储了患者信息
        UseraccountDTO loginUser = (UseraccountDTO) session.getAttribute("logUser");
        String patientId = String.valueOf(loginUser.getPatient().getPatientId());
        caseinfo.getParam().setEnterPerson(patientId);
        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
    }

    @PostMapping("/getCaseList")
    public ResultDTO<PageInfo<CaseDTO>> getCaseList(@RequestBody PageRequestDTO<CaseDTO> caseinfo) {
        return ResultDTO.valueOfSuccess(caseService.getCaseList(caseinfo));
    }

    @PostMapping("/getCaseListByPatientName")
    public ResultDTO<PageInfo<CaseDTO>> getCaseListByPatientName(@RequestBody String patientName, int pageNum, int pageSize) {
        return ResultDTO.valueOfSuccess(caseService.getCaseListByPatientName(patientName, pageNum, pageSize));
    }

    private CaseInfoDTO fillCaseAll(CaseDTO caseInfo,PatientDTO patient,List<CaseMedicineDetailDTO> detailList) {
        CaseInfoDTO caseAll = new CaseInfoDTO();
        caseAll.setCaseId(caseInfo.getCaseId());
        caseAll.setCureCycle(caseInfo.getCureCycle());
        caseAll.setCureTime(caseInfo.getCureTime());
        caseAll.setDetailList(detailList);
        caseAll.setDoctorName(caseInfo.getDoctorName());
        caseAll.setIllnessDesc(caseInfo.getIllnessDesc());
        caseAll.setIllnessGrade(caseInfo.getIllnessGrade());
        caseAll.setIllnessTime(caseInfo.getIllnessTime());
        caseAll.setPatientAge(patient.getPatientBorn());
        caseAll.setPatientId(""+patient.getPatientId());
        caseAll.setPatientName(patient.getPatientName());
        caseAll.setPatientSex(patient.getPatientSex());
        return caseAll;
    }
    

}

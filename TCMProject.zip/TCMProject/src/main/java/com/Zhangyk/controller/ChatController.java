package com.Zhangyk.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ChatController {

    @Value("${deepseek.api.key}")
    private String apiKey;

    @Value("${deepseek.api.base-url}")
    private String baseUrl;

    @Value("${deepseek.chat.system-prompt}")
    private String systemPrompt;

    private final RestTemplate rt = new RestTemplate();

    @PostMapping("/chat")
    public Map<String, String> chat(@RequestBody Map<String, String> body) {
        String question = body.get("question");
        if (question == null || question.trim().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "缺少 question 字段");
        }

        // 1. 构造请求头
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(apiKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        // 2. 构造 payload
        Map<String, Object> payload = new HashMap<>();
        payload.put("model", "deepseek-r1:1.5b");

        List<Map<String, String>> messages = new ArrayList<>();

        Map<String, String> sysMsg = new HashMap<>();
        sysMsg.put("role", "system");
        sysMsg.put("content", systemPrompt);
        messages.add(sysMsg);

        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", question);
        messages.add(userMsg);

        payload.put("messages", messages);

        // 3. 发送请求到 DeepSeek
        HttpEntity<Map<String, Object>> req = new HttpEntity<>(payload, headers);
        @SuppressWarnings("unchecked")
        Map<String, Object> resp = rt.postForObject(
                baseUrl + "/chat/completions",
                req,
                Map.class
        );

        // 4. 解析回答
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> choices =
                (List<Map<String, Object>>) resp.get("choices");
        @SuppressWarnings("unchecked")
        Map<String, Object> message =
                (Map<String, Object>) choices.get(0).get("message");
        String answer = ((String) message.get("content")).trim();

        // 返回给前端
        return Collections.singletonMap("answer", answer);
    }
}

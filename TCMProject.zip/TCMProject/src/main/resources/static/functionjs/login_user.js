$(function (){
	getLogUser();
});
function getLogUser(){
    $.ajax({
        async: false,
        type: "get",
        contentType: "application/json;charset=UTF-8",
        url: "http://localhost:8080/sys/getLoginUser",
        success:function(result){
            if(result.success){
                const user = result.value;

                // 显示登录用户名
                $("#loginName").text(user.userName);

                // ✅ 保存病人姓名到 sessionStorage
                if (user.patient && user.patient.patientName) {
                    sessionStorage.setItem("patientName", user.patient.patientName);
                } else {
                    sessionStorage.setItem("patientName", "未绑定病人");
                }

            } else {
                // 登录失效或异常，跳转到登录页
                window.location.href = "http://localhost:8080/login";
            }
        }
    });
}
